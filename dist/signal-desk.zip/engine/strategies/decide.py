"""Is this signal a real trade, or just something to watch?

A signal is graded "take" only if it passes four checks. They were chosen because, on 60 days of real prices,
each one separated better trades from worse ones in BOTH halves of the period, and none of them is a tuned number:

  cost    the round-trip cost is no more than 25% of the amount risked. A stop too tight for the costs means the
          trade starts the day behind; this was by far the biggest single factor.
  volume  the stock is trading at 2x its usual volume or more for this time of day (it is "in play").
          Indices have no volume, so they pass.
  market  Nifty is on the same side of its own average price line (VWAP) as the trade.
  conflict  no other strategy has already taken the opposite side of the same stock today.

Everything else is "watch". The grade says how good the setup is, not that it is profitable: in the backtest even
trades that pass all four checks lost a little after costs. Nothing here places an order.
"""
DEFAULTS = {"max_cost_ratio": 0.25, "min_volume": 2.0, "need_market": True, "no_conflict": True}

CHECK_NAMES = {"cost": "Stop wide enough for the costs", "vol": "Heavy volume", "mkt": "Nifty agrees", "conf": "No conflicting signal"}


def settings(cfg):
    out = dict(DEFAULTS)
    out.update(((cfg or {}).get("strategies") or {}).get("decide") or {})
    return out


def assess(S, i, tr, cost_est, mkt, dc):
    """Grades one trade at the moment it triggers. Conflicts are added afterwards by finalize()."""
    d = tr["dir"]
    cr = cost_est / tr["risk"] if tr["risk"] else 9.0
    cv = S.cumratio[i] if S.has_volume else None
    nm = None
    if mkt is not None and tr["symbol"] != getattr(mkt, "symbol", None):
        j = mkt.index_of(S.t[i])
        if j is not None and mkt.vwap[j] is not None:
            nm = d * (mkt.c[j] - mkt.vwap[j]) > 0
    fails = []
    if cr > dc["max_cost_ratio"]:
        fails.append("cost")
    if cv is not None and cv < dc["min_volume"]:
        fails.append("vol")
    if dc["need_market"] and nm is False:
        fails.append("mkt")
    return {"g": "watch" if fails else "take", "f": fails, "cr": round(cr, 2), "cv": None if cv is None else round(cv, 1), "nm": nm, "cf": 0}


def finalize(trades, dc):
    """Adds the conflict check: another strategy already on the opposite side of the same stock today."""
    by = {}
    for t in trades:
        by.setdefault((t["date"], t["symbol"]), []).append(t)
    for lst in by.values():
        if len(lst) < 2:
            continue
        for t in lst:
            n = sum(1 for o in lst if o["dir"] == -t["dir"] and o["entry_ts"] <= t["entry_ts"])
            dec = t.get("dec")
            if not dec:
                continue
            dec["cf"] = n
            if n and dc["no_conflict"] and "conf" not in dec["f"]:
                dec["f"].append("conf")
                dec["g"] = "watch"
    return trades
